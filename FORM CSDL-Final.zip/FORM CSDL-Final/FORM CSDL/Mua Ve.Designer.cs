﻿namespace FORM_CSDL
{
    partial class Mua_Ve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_CMND = new System.Windows.Forms.TextBox();
            this.text_MaCB = new System.Windows.Forms.TextBox();
            this.date_catcanh = new System.Windows.Forms.TextBox();
            this.date_hacanh = new System.Windows.Forms.TextBox();
            this.textBox_Soghe = new System.Windows.Forms.TextBox();
            this.comboBox_noiden = new System.Windows.Forms.ComboBox();
            this.comboBox_noidi = new System.Windows.Forms.ComboBox();
            this.date_can_bay = new System.Windows.Forms.DateTimePicker();
            this.combo_giave = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "MaCB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 259);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Thòi gian hạ cánh";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Thời gian cất cánh";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 375);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(486, 190);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(365, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Gía vé";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(365, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Số ghế";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(355, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Nơi đến";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(355, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Nơi đi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(320, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "Ngày cần bay";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 16);
            this.label10.TabIndex = 10;
            this.label10.Text = "CMND";
            // 
            // textBox_CMND
            // 
            this.textBox_CMND.Location = new System.Drawing.Point(162, 55);
            this.textBox_CMND.Name = "textBox_CMND";
            this.textBox_CMND.Size = new System.Drawing.Size(100, 22);
            this.textBox_CMND.TabIndex = 11;
            // 
            // text_MaCB
            // 
            this.text_MaCB.Location = new System.Drawing.Point(162, 113);
            this.text_MaCB.Name = "text_MaCB";
            this.text_MaCB.ReadOnly = true;
            this.text_MaCB.Size = new System.Drawing.Size(100, 22);
            this.text_MaCB.TabIndex = 12;
            // 
            // date_catcanh
            // 
            this.date_catcanh.Location = new System.Drawing.Point(162, 194);
            this.date_catcanh.Name = "date_catcanh";
            this.date_catcanh.ReadOnly = true;
            this.date_catcanh.Size = new System.Drawing.Size(100, 22);
            this.date_catcanh.TabIndex = 13;
            // 
            // date_hacanh
            // 
            this.date_hacanh.Location = new System.Drawing.Point(162, 256);
            this.date_hacanh.Name = "date_hacanh";
            this.date_hacanh.ReadOnly = true;
            this.date_hacanh.Size = new System.Drawing.Size(100, 22);
            this.date_hacanh.TabIndex = 14;
            // 
            // textBox_Soghe
            // 
            this.textBox_Soghe.Location = new System.Drawing.Point(467, 259);
            this.textBox_Soghe.Name = "textBox_Soghe";
            this.textBox_Soghe.Size = new System.Drawing.Size(143, 22);
            this.textBox_Soghe.TabIndex = 15;
            // 
            // comboBox_noiden
            // 
            this.comboBox_noiden.FormattingEnabled = true;
            this.comboBox_noiden.Items.AddRange(new object[] {
            "HCM",
            "Ha Noi",
            "Da Nang"});
            this.comboBox_noiden.Location = new System.Drawing.Point(467, 188);
            this.comboBox_noiden.Name = "comboBox_noiden";
            this.comboBox_noiden.Size = new System.Drawing.Size(143, 24);
            this.comboBox_noiden.TabIndex = 16;
            // 
            // comboBox_noidi
            // 
            this.comboBox_noidi.FormattingEnabled = true;
            this.comboBox_noidi.Items.AddRange(new object[] {
            "HCM",
            "Ha Noi",
            "Da Nang"});
            this.comboBox_noidi.Location = new System.Drawing.Point(467, 111);
            this.comboBox_noidi.Name = "comboBox_noidi";
            this.comboBox_noidi.Size = new System.Drawing.Size(143, 24);
            this.comboBox_noidi.TabIndex = 17;
            // 
            // date_can_bay
            // 
            this.date_can_bay.CustomFormat = " yyyy-MM-dd";
            this.date_can_bay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_can_bay.Location = new System.Drawing.Point(467, 55);
            this.date_can_bay.Name = "date_can_bay";
            this.date_can_bay.Size = new System.Drawing.Size(143, 22);
            this.date_can_bay.TabIndex = 19;
            // 
            // combo_giave
            // 
            this.combo_giave.FormattingEnabled = true;
            this.combo_giave.Items.AddRange(new object[] {
            "100000",
            "200000",
            "300000"});
            this.combo_giave.Location = new System.Drawing.Point(467, 321);
            this.combo_giave.Name = "combo_giave";
            this.combo_giave.Size = new System.Drawing.Size(143, 24);
            this.combo_giave.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 332);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Gợi ý lịch bay";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(535, 542);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "EXIT";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(535, 456);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 23;
            this.button3.Text = "Đặt vé";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Mua_Ve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 588);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.combo_giave);
            this.Controls.Add(this.date_can_bay);
            this.Controls.Add(this.comboBox_noidi);
            this.Controls.Add(this.comboBox_noiden);
            this.Controls.Add(this.textBox_Soghe);
            this.Controls.Add(this.date_hacanh);
            this.Controls.Add(this.date_catcanh);
            this.Controls.Add(this.text_MaCB);
            this.Controls.Add(this.textBox_CMND);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Mua_Ve";
            this.Text = "Mua_Ve";
            this.Load += new System.EventHandler(this.Mua_Ve_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_CMND;
        private System.Windows.Forms.TextBox text_MaCB;
        private System.Windows.Forms.TextBox date_catcanh;
        private System.Windows.Forms.TextBox date_hacanh;
        private System.Windows.Forms.TextBox textBox_Soghe;
        private System.Windows.Forms.ComboBox comboBox_noiden;
        private System.Windows.Forms.ComboBox comboBox_noidi;
        private System.Windows.Forms.DateTimePicker date_can_bay;
        private System.Windows.Forms.ComboBox combo_giave;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}