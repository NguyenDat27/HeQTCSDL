﻿
namespace FORM_CSDL
{
    partial class PhiCong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_giobay = new System.Windows.Forms.TextBox();
            this.text_Luong = new System.Windows.Forms.TextBox();
            this.text_SDT = new System.Windows.Forms.TextBox();
            this.text_DiaChi = new System.Windows.Forms.TextBox();
            this.text_TenPC = new System.Windows.Forms.TextBox();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.text_MaPC = new System.Windows.Forms.TextBox();
            this.button_add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // text_giobay
            // 
            this.text_giobay.Location = new System.Drawing.Point(690, 312);
            this.text_giobay.Name = "text_giobay";
            this.text_giobay.ReadOnly = true;
            this.text_giobay.Size = new System.Drawing.Size(152, 22);
            this.text_giobay.TabIndex = 34;
            // 
            // text_Luong
            // 
            this.text_Luong.Location = new System.Drawing.Point(690, 266);
            this.text_Luong.Name = "text_Luong";
            this.text_Luong.ReadOnly = true;
            this.text_Luong.Size = new System.Drawing.Size(152, 22);
            this.text_Luong.TabIndex = 33;
            this.text_Luong.TextChanged += new System.EventHandler(this.text_Luong_TextChanged);
            // 
            // text_SDT
            // 
            this.text_SDT.Location = new System.Drawing.Point(690, 228);
            this.text_SDT.Name = "text_SDT";
            this.text_SDT.Size = new System.Drawing.Size(152, 22);
            this.text_SDT.TabIndex = 32;
            // 
            // text_DiaChi
            // 
            this.text_DiaChi.Location = new System.Drawing.Point(690, 192);
            this.text_DiaChi.Name = "text_DiaChi";
            this.text_DiaChi.Size = new System.Drawing.Size(152, 22);
            this.text_DiaChi.TabIndex = 31;
            // 
            // text_TenPC
            // 
            this.text_TenPC.Location = new System.Drawing.Point(690, 155);
            this.text_TenPC.Name = "text_TenPC";
            this.text_TenPC.Size = new System.Drawing.Size(152, 22);
            this.text_TenPC.TabIndex = 30;
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(696, 404);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(75, 23);
            this.button_exit.TabIndex = 29;
            this.button_exit.Text = "Thoat";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_xoa
            // 
            this.button_xoa.Location = new System.Drawing.Point(532, 404);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(75, 23);
            this.button_xoa.TabIndex = 28;
            this.button_xoa.Text = "xóa";
            this.button_xoa.UseVisualStyleBackColor = true;
            this.button_xoa.Click += new System.EventHandler(this.button_xoa_Click);
            // 
            // button_update
            // 
            this.button_update.Location = new System.Drawing.Point(347, 404);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(75, 23);
            this.button_update.TabIndex = 27;
            this.button_update.Text = "Sửa";
            this.button_update.UseVisualStyleBackColor = true;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(612, 312);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 16);
            this.label6.TabIndex = 26;
            this.label6.Text = "Gio bay";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(612, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 25;
            this.label5.Text = "Lương";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(612, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "SĐT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(612, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Địa chỉ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(612, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "TenPC";
            // 
            // text_MaPC
            // 
            this.text_MaPC.Location = new System.Drawing.Point(690, 109);
            this.text_MaPC.Name = "text_MaPC";
            this.text_MaPC.Size = new System.Drawing.Size(143, 22);
            this.text_MaPC.TabIndex = 21;
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(156, 404);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 23);
            this.button_add.TabIndex = 20;
            this.button_add.Text = "Thêm";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(612, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "MaPC";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(54, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(489, 243);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // PhiCong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 463);
            this.Controls.Add(this.text_giobay);
            this.Controls.Add(this.text_Luong);
            this.Controls.Add(this.text_SDT);
            this.Controls.Add(this.text_DiaChi);
            this.Controls.Add(this.text_TenPC);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_MaPC);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PhiCong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PhiCong";
            this.Load += new System.EventHandler(this.PhiCong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_giobay;
        private System.Windows.Forms.TextBox text_Luong;
        private System.Windows.Forms.TextBox text_SDT;
        private System.Windows.Forms.TextBox text_DiaChi;
        private System.Windows.Forms.TextBox text_TenPC;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_xoa;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox text_MaPC;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}