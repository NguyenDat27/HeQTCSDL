﻿
namespace FORM_CSDL
{
    partial class Quan_li
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quan_li));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.xửLíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hk = new System.Windows.Forms.ToolStripMenuItem();
            this.lb = new System.Windows.Forms.ToolStripMenuItem();
            this.lmb = new System.Windows.Forms.ToolStripMenuItem();
            this.mb = new System.Windows.Forms.ToolStripMenuItem();
            this.ve = new System.Windows.Forms.ToolStripMenuItem();
            this.pc = new System.Windows.Forms.ToolStripMenuItem();
            this.kn = new System.Windows.Forms.ToolStripMenuItem();
            this.tínhNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loc = new System.Windows.Forms.ToolStripMenuItem();
            this.slv = new System.Windows.Forms.ToolStripMenuItem();
            this.ttcb = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmb = new System.Windows.Forms.ToolStripMenuItem();
            this.tkl = new System.Windows.Forms.ToolStripMenuItem();
            this.tkmb = new System.Windows.Forms.ToolStripMenuItem();
            this.tùyChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dangsuat = new System.Windows.Forms.ToolStripMenuItem();
            this.thoat = new System.Windows.Forms.ToolStripMenuItem();
            this.pq = new System.Windows.Forms.ToolStripMenuItem();
            this.xpq = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xửLíToolStripMenuItem,
            this.tínhNăngToolStripMenuItem,
            this.tùyChọnToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(824, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // xửLíToolStripMenuItem
            // 
            this.xửLíToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hk,
            this.lb,
            this.lmb,
            this.mb,
            this.ve,
            this.pc,
            this.kn});
            this.xửLíToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xửLíToolStripMenuItem.Name = "xửLíToolStripMenuItem";
            this.xửLíToolStripMenuItem.Size = new System.Drawing.Size(84, 36);
            this.xửLíToolStripMenuItem.Text = "Xử lí";
            // 
            // hk
            // 
            this.hk.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hk.Name = "hk";
            this.hk.Size = new System.Drawing.Size(235, 36);
            this.hk.Text = "Hành khách";
            this.hk.Click += new System.EventHandler(this.hk_Click);
            // 
            // lb
            // 
            this.lb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(235, 36);
            this.lb.Text = "Lịch bay";
            this.lb.Click += new System.EventHandler(this.lb_Click);
            // 
            // lmb
            // 
            this.lmb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lmb.Name = "lmb";
            this.lmb.Size = new System.Drawing.Size(235, 36);
            this.lmb.Text = "Loại máy bay";
            this.lmb.Click += new System.EventHandler(this.lmb_Click);
            // 
            // mb
            // 
            this.mb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mb.Name = "mb";
            this.mb.Size = new System.Drawing.Size(235, 36);
            this.mb.Text = "Máy bay";
            this.mb.Click += new System.EventHandler(this.mb_Click);
            // 
            // ve
            // 
            this.ve.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ve.Name = "ve";
            this.ve.Size = new System.Drawing.Size(235, 36);
            this.ve.Text = "Vé";
            this.ve.Click += new System.EventHandler(this.ve_Click);
            // 
            // pc
            // 
            this.pc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pc.Name = "pc";
            this.pc.Size = new System.Drawing.Size(235, 36);
            this.pc.Text = "Phi công";
            this.pc.Click += new System.EventHandler(this.pc_Click);
            // 
            // kn
            // 
            this.kn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kn.Name = "kn";
            this.kn.Size = new System.Drawing.Size(235, 36);
            this.kn.Text = "Khả năng";
            this.kn.Click += new System.EventHandler(this.kn_Click);
            // 
            // tínhNăngToolStripMenuItem
            // 
            this.tínhNăngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loc,
            this.slv,
            this.ttcb,
            this.tsmb,
            this.tkl,
            this.tkmb,
            this.pq,
            this.xpq});
            this.tínhNăngToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tínhNăngToolStripMenuItem.Name = "tínhNăngToolStripMenuItem";
            this.tínhNăngToolStripMenuItem.Size = new System.Drawing.Size(146, 36);
            this.tínhNăngToolStripMenuItem.Text = "Tính năng";
            // 
            // loc
            // 
            this.loc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc.Name = "loc";
            this.loc.Size = new System.Drawing.Size(482, 36);
            this.loc.Text = "Lọc DS chuyến bay";
            this.loc.Click += new System.EventHandler(this.loc_Click);
            // 
            // slv
            // 
            this.slv.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slv.Name = "slv";
            this.slv.Size = new System.Drawing.Size(482, 36);
            this.slv.Text = "Số lượng vé mỗi tháng";
            this.slv.Click += new System.EventHandler(this.slv_Click);
            // 
            // ttcb
            // 
            this.ttcb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ttcb.Name = "ttcb";
            this.ttcb.Size = new System.Drawing.Size(482, 36);
            this.ttcb.Text = "Tình trạng chuyến bay";
            this.ttcb.Click += new System.EventHandler(this.ttcb_Click);
            // 
            // tsmb
            // 
            this.tsmb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmb.Name = "tsmb";
            this.tsmb.Size = new System.Drawing.Size(482, 36);
            this.tsmb.Text = "Tổng số máy bay";
            this.tsmb.Click += new System.EventHandler(this.tsmb_Click);
            // 
            // tkl
            // 
            this.tkl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tkl.Name = "tkl";
            this.tkl.Size = new System.Drawing.Size(482, 36);
            this.tkl.Text = "Thống kê lương phi công";
            this.tkl.Click += new System.EventHandler(this.tkl_Click);
            // 
            // tkmb
            // 
            this.tkmb.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tkmb.Name = "tkmb";
            this.tkmb.Size = new System.Drawing.Size(482, 36);
            this.tkmb.Text = "Thống kê số lượng máy bay theo mỗi loại";
            this.tkmb.Click += new System.EventHandler(this.tkmb_Click);
            // 
            // tùyChọnToolStripMenuItem
            // 
            this.tùyChọnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dangsuat,
            this.thoat});
            this.tùyChọnToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tùyChọnToolStripMenuItem.Name = "tùyChọnToolStripMenuItem";
            this.tùyChọnToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.tùyChọnToolStripMenuItem.Text = "Tùy chọn";
            // 
            // dangsuat
            // 
            this.dangsuat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dangsuat.Name = "dangsuat";
            this.dangsuat.Size = new System.Drawing.Size(270, 36);
            this.dangsuat.Text = "Đăng xuất ";
            this.dangsuat.Click += new System.EventHandler(this.dangsuat_Click);
            // 
            // thoat
            // 
            this.thoat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thoat.Name = "thoat";
            this.thoat.Size = new System.Drawing.Size(270, 36);
            this.thoat.Text = "Thoát";
            this.thoat.Click += new System.EventHandler(this.thoat_Click);
            // 
            // pq
            // 
            this.pq.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pq.Name = "pq";
            this.pq.Size = new System.Drawing.Size(482, 36);
            this.pq.Text = "Phân quyền";
            this.pq.Click += new System.EventHandler(this.pq_Click);
            // 
            // xpq
            // 
            this.xpq.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xpq.Name = "xpq";
            this.xpq.Size = new System.Drawing.Size(482, 36);
            this.xpq.Text = "Xem phân quyền";
            this.xpq.Click += new System.EventHandler(this.xpq_Click);
            // 
            // Quan_li
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(824, 518);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Quan_li";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lí";
            this.Load += new System.EventHandler(this.Quan_li_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem xửLíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hk;
        private System.Windows.Forms.ToolStripMenuItem lb;
        private System.Windows.Forms.ToolStripMenuItem lmb;
        private System.Windows.Forms.ToolStripMenuItem mb;
        private System.Windows.Forms.ToolStripMenuItem ve;
        private System.Windows.Forms.ToolStripMenuItem tínhNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loc;
        private System.Windows.Forms.ToolStripMenuItem slv;
        private System.Windows.Forms.ToolStripMenuItem ttcb;
        private System.Windows.Forms.ToolStripMenuItem tsmb;
        private System.Windows.Forms.ToolStripMenuItem tkl;
        private System.Windows.Forms.ToolStripMenuItem tkmb;
        private System.Windows.Forms.ToolStripMenuItem tùyChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dangsuat;
        private System.Windows.Forms.ToolStripMenuItem thoat;
        private System.Windows.Forms.ToolStripMenuItem pc;
        private System.Windows.Forms.ToolStripMenuItem kn;
        private System.Windows.Forms.ToolStripMenuItem pq;
        private System.Windows.Forms.ToolStripMenuItem xpq;
    }
}