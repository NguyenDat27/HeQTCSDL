﻿namespace FORM_CSDL
{
    partial class Ve_for_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_add = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_Xoa = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.com = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.text_CMND = new System.Windows.Forms.TextBox();
            this.text_MaCB = new System.Windows.Forms.TextBox();
            this.text_Soghe = new System.Windows.Forms.TextBox();
            this.text_GiaVe = new System.Windows.Forms.TextBox();
            this.text_Phiphatsinh = new System.Windows.Forms.TextBox();
            this.text_khuyenmai = new System.Windows.Forms.TextBox();
            this.date_catcanh = new System.Windows.Forms.DateTimePicker();
            this.date_hacanh = new System.Windows.Forms.DateTimePicker();
            this.date_canbay = new System.Windows.Forms.DateTimePicker();
            this.com_candi = new System.Windows.Forms.ComboBox();
            this.combo_canden = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.text_ID = new System.Windows.Forms.TextBox();
            this.text_Trang_thai = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(48, 381);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 23);
            this.button_add.TabIndex = 0;
            this.button_add.Text = "Thêm";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_update
            // 
            this.button_update.Location = new System.Drawing.Point(278, 381);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(75, 23);
            this.button_update.TabIndex = 1;
            this.button_update.Text = "Sửa";
            this.button_update.UseVisualStyleBackColor = true;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_Xoa
            // 
            this.button_Xoa.Location = new System.Drawing.Point(619, 381);
            this.button_Xoa.Name = "button_Xoa";
            this.button_Xoa.Size = new System.Drawing.Size(75, 23);
            this.button_Xoa.TabIndex = 2;
            this.button_Xoa.Text = "Xóa";
            this.button_Xoa.UseVisualStyleBackColor = true;
            this.button_Xoa.Click += new System.EventHandler(this.button_Xoa_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(990, 381);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "EXIT";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(352, 311);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // com
            // 
            this.com.AutoSize = true;
            this.com.Location = new System.Drawing.Point(407, 288);
            this.com.Name = "com";
            this.com.Size = new System.Drawing.Size(67, 16);
            this.com.TabIndex = 7;
            this.com.Text = "Nơi cần đi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(831, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Gía vé";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(406, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Thời gian cần đi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(407, 332);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Nơi cần đến";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(406, 83);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "MaCB";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(406, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "CMND HK";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(370, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 16);
            this.label9.TabIndex = 13;
            this.label9.Text = "Thoi gian cất cánh";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(831, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 16);
            this.label10.TabIndex = 14;
            this.label10.Text = "Trạng thái vé";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(831, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 16);
            this.label11.TabIndex = 15;
            this.label11.Text = "Số ghế";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(406, 187);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 16);
            this.label12.TabIndex = 16;
            this.label12.Text = "Thời gian hạ cánh";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(831, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Phí phát sinh";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(831, 239);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 16);
            this.label13.TabIndex = 19;
            this.label13.Text = "Khuyến mãi";
            // 
            // text_CMND
            // 
            this.text_CMND.Location = new System.Drawing.Point(525, 30);
            this.text_CMND.Name = "text_CMND";
            this.text_CMND.Size = new System.Drawing.Size(227, 22);
            this.text_CMND.TabIndex = 20;
            // 
            // text_MaCB
            // 
            this.text_MaCB.Location = new System.Drawing.Point(525, 80);
            this.text_MaCB.Name = "text_MaCB";
            this.text_MaCB.Size = new System.Drawing.Size(227, 22);
            this.text_MaCB.TabIndex = 21;
            // 
            // text_Soghe
            // 
            this.text_Soghe.Location = new System.Drawing.Point(981, 77);
            this.text_Soghe.Name = "text_Soghe";
            this.text_Soghe.Size = new System.Drawing.Size(124, 22);
            this.text_Soghe.TabIndex = 22;
            // 
            // text_GiaVe
            // 
            this.text_GiaVe.Location = new System.Drawing.Point(981, 135);
            this.text_GiaVe.Name = "text_GiaVe";
            this.text_GiaVe.Size = new System.Drawing.Size(124, 22);
            this.text_GiaVe.TabIndex = 23;
            // 
            // text_Phiphatsinh
            // 
            this.text_Phiphatsinh.Location = new System.Drawing.Point(981, 184);
            this.text_Phiphatsinh.Name = "text_Phiphatsinh";
            this.text_Phiphatsinh.ReadOnly = true;
            this.text_Phiphatsinh.Size = new System.Drawing.Size(124, 22);
            this.text_Phiphatsinh.TabIndex = 24;
            // 
            // text_khuyenmai
            // 
            this.text_khuyenmai.Location = new System.Drawing.Point(981, 233);
            this.text_khuyenmai.Name = "text_khuyenmai";
            this.text_khuyenmai.ReadOnly = true;
            this.text_khuyenmai.Size = new System.Drawing.Size(124, 22);
            this.text_khuyenmai.TabIndex = 25;
            // 
            // date_catcanh
            // 
            this.date_catcanh.CustomFormat = "yyyy-MM-dd    HH:mm";
            this.date_catcanh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_catcanh.Location = new System.Drawing.Point(526, 133);
            this.date_catcanh.Name = "date_catcanh";
            this.date_catcanh.Size = new System.Drawing.Size(226, 22);
            this.date_catcanh.TabIndex = 26;
            // 
            // date_hacanh
            // 
            this.date_hacanh.CustomFormat = "yyyy-MM-dd    HH:mm";
            this.date_hacanh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_hacanh.Location = new System.Drawing.Point(525, 181);
            this.date_hacanh.Name = "date_hacanh";
            this.date_hacanh.Size = new System.Drawing.Size(227, 22);
            this.date_hacanh.TabIndex = 27;
            // 
            // date_canbay
            // 
            this.date_canbay.CustomFormat = "yyyy-MM-dd ";
            this.date_canbay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_canbay.Location = new System.Drawing.Point(525, 234);
            this.date_canbay.Name = "date_canbay";
            this.date_canbay.Size = new System.Drawing.Size(227, 22);
            this.date_canbay.TabIndex = 28;
            // 
            // com_candi
            // 
            this.com_candi.FormattingEnabled = true;
            this.com_candi.Items.AddRange(new object[] {
            "HCM",
            "Ha Noi",
            "Da Nang"});
            this.com_candi.Location = new System.Drawing.Point(525, 280);
            this.com_candi.Name = "com_candi";
            this.com_candi.Size = new System.Drawing.Size(227, 24);
            this.com_candi.TabIndex = 29;
            // 
            // combo_canden
            // 
            this.combo_canden.FormattingEnabled = true;
            this.combo_canden.Items.AddRange(new object[] {
            "HCM",
            "Ha Noi",
            "Da Nang"});
            this.combo_canden.Location = new System.Drawing.Point(526, 324);
            this.combo_canden.Name = "combo_canden";
            this.combo_canden.Size = new System.Drawing.Size(226, 24);
            this.combo_canden.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(834, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "ID";
            // 
            // text_ID
            // 
            this.text_ID.Location = new System.Drawing.Point(981, 281);
            this.text_ID.Name = "text_ID";
            this.text_ID.ReadOnly = true;
            this.text_ID.Size = new System.Drawing.Size(124, 22);
            this.text_ID.TabIndex = 33;
            // 
            // text_Trang_thai
            // 
            this.text_Trang_thai.Location = new System.Drawing.Point(981, 21);
            this.text_Trang_thai.Name = "text_Trang_thai";
            this.text_Trang_thai.ReadOnly = true;
            this.text_Trang_thai.Size = new System.Drawing.Size(100, 22);
            this.text_Trang_thai.TabIndex = 34;
            // 
            // Ve_for_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 450);
            this.Controls.Add(this.text_Trang_thai);
            this.Controls.Add(this.text_ID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combo_canden);
            this.Controls.Add(this.com_candi);
            this.Controls.Add(this.date_canbay);
            this.Controls.Add(this.date_hacanh);
            this.Controls.Add(this.date_catcanh);
            this.Controls.Add(this.text_khuyenmai);
            this.Controls.Add(this.text_Phiphatsinh);
            this.Controls.Add(this.text_GiaVe);
            this.Controls.Add(this.text_Soghe);
            this.Controls.Add(this.text_MaCB);
            this.Controls.Add(this.text_CMND);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.com);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button_Xoa);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_add);
            this.Name = "Ve_for_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ve_for_admin";
            this.Load += new System.EventHandler(this.Ve_for_admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_Xoa;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label com;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox text_CMND;
        private System.Windows.Forms.TextBox text_MaCB;
        private System.Windows.Forms.TextBox text_Soghe;
        private System.Windows.Forms.TextBox text_GiaVe;
        private System.Windows.Forms.TextBox text_Phiphatsinh;
        private System.Windows.Forms.TextBox text_khuyenmai;
        private System.Windows.Forms.DateTimePicker date_catcanh;
        private System.Windows.Forms.DateTimePicker date_hacanh;
        private System.Windows.Forms.DateTimePicker date_canbay;
        private System.Windows.Forms.ComboBox com_candi;
        private System.Windows.Forms.ComboBox combo_canden;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_ID;
        private System.Windows.Forms.TextBox text_Trang_thai;
    }
}