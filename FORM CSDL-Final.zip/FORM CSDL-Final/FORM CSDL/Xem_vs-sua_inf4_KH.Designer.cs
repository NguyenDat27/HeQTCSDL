﻿namespace FORM_CSDL
{
    partial class Xem_vs_sua_inf4_KH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_CMND = new System.Windows.Forms.TextBox();
            this.textBox_Hoten = new System.Windows.Forms.TextBox();
            this.textBox_Diachi = new System.Windows.Forms.TextBox();
            this.textBox_SDT = new System.Windows.Forms.TextBox();
            this.button_reset = new System.Windows.Forms.Button();
            this.button_UPDATE = new System.Windows.Forms.Button();
            this.button_FIND = new System.Windows.Forms.Button();
            this.button_EXIT = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.date_sinh = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(238, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "THÔNG TIN KHÁCH HÀNG";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "CMND";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Họ và tên";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ngày sinh";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Địa chỉ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Số điện thoại";
            // 
            // textBox_CMND
            // 
            this.textBox_CMND.Location = new System.Drawing.Point(186, 56);
            this.textBox_CMND.Name = "textBox_CMND";
            this.textBox_CMND.Size = new System.Drawing.Size(200, 22);
            this.textBox_CMND.TabIndex = 7;
            // 
            // textBox_Hoten
            // 
            this.textBox_Hoten.Location = new System.Drawing.Point(186, 100);
            this.textBox_Hoten.Name = "textBox_Hoten";
            this.textBox_Hoten.Size = new System.Drawing.Size(200, 22);
            this.textBox_Hoten.TabIndex = 8;
            this.textBox_Hoten.TextChanged += new System.EventHandler(this.textBox_Hoten_TextChanged);
            // 
            // textBox_Diachi
            // 
            this.textBox_Diachi.Location = new System.Drawing.Point(186, 158);
            this.textBox_Diachi.Name = "textBox_Diachi";
            this.textBox_Diachi.Size = new System.Drawing.Size(200, 22);
            this.textBox_Diachi.TabIndex = 9;
            // 
            // textBox_SDT
            // 
            this.textBox_SDT.Location = new System.Drawing.Point(186, 207);
            this.textBox_SDT.Name = "textBox_SDT";
            this.textBox_SDT.Size = new System.Drawing.Size(200, 22);
            this.textBox_SDT.TabIndex = 10;
            // 
            // button_reset
            // 
            this.button_reset.Location = new System.Drawing.Point(450, 415);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(75, 23);
            this.button_reset.TabIndex = 11;
            this.button_reset.Text = "RESET";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click);
            // 
            // button_UPDATE
            // 
            this.button_UPDATE.Location = new System.Drawing.Point(223, 415);
            this.button_UPDATE.Name = "button_UPDATE";
            this.button_UPDATE.Size = new System.Drawing.Size(75, 23);
            this.button_UPDATE.TabIndex = 12;
            this.button_UPDATE.Text = "UPDATE";
            this.button_UPDATE.UseVisualStyleBackColor = true;
            this.button_UPDATE.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_FIND
            // 
            this.button_FIND.Location = new System.Drawing.Point(46, 415);
            this.button_FIND.Name = "button_FIND";
            this.button_FIND.Size = new System.Drawing.Size(75, 23);
            this.button_FIND.TabIndex = 13;
            this.button_FIND.Text = "Find";
            this.button_FIND.UseVisualStyleBackColor = true;
            this.button_FIND.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_EXIT
            // 
            this.button_EXIT.Location = new System.Drawing.Point(661, 415);
            this.button_EXIT.Name = "button_EXIT";
            this.button_EXIT.Size = new System.Drawing.Size(75, 23);
            this.button_EXIT.TabIndex = 14;
            this.button_EXIT.Text = "EXIT";
            this.button_EXIT.UseVisualStyleBackColor = true;
            this.button_EXIT.Click += new System.EventHandler(this.button_EXIT_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(46, 298);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(648, 91);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // date_sinh
            // 
            this.date_sinh.CustomFormat = " yyyy-MM-dd";
            this.date_sinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_sinh.Location = new System.Drawing.Point(186, 254);
            this.date_sinh.Name = "date_sinh";
            this.date_sinh.Size = new System.Drawing.Size(200, 22);
            this.date_sinh.TabIndex = 16;
            // 
            // Xem_vs_sua_inf4_KH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.date_sinh);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_EXIT);
            this.Controls.Add(this.button_FIND);
            this.Controls.Add(this.button_UPDATE);
            this.Controls.Add(this.button_reset);
            this.Controls.Add(this.textBox_SDT);
            this.Controls.Add(this.textBox_Diachi);
            this.Controls.Add(this.textBox_Hoten);
            this.Controls.Add(this.textBox_CMND);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Xem_vs_sua_inf4_KH";
            this.Text = "Xem_vs_sua_inf4_KH";
            this.Load += new System.EventHandler(this.Xem_vs_sua_inf4_KH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_CMND;
        private System.Windows.Forms.TextBox textBox_Hoten;
        private System.Windows.Forms.TextBox textBox_Diachi;
        private System.Windows.Forms.TextBox textBox_SDT;
        private System.Windows.Forms.Button button_reset;
        private System.Windows.Forms.Button button_UPDATE;
        private System.Windows.Forms.Button button_FIND;
        private System.Windows.Forms.Button button_EXIT;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker date_sinh;
    }
}